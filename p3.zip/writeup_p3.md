#**Behavioral Cloning** 

##Writeup Template

###You can use this file as a template for your writeup if you want to submit it as a markdown file, but feel free to use some other method and submit a pdf if you prefer.

---

**Build a Behavioral Cloning Project**

1,choosing a powerful model is a important work, the nvidia network is much better than others.
2,collecting data is also remarkable work too
3,setting the right speed, that your computer may not fast enough to handle the calculating.
